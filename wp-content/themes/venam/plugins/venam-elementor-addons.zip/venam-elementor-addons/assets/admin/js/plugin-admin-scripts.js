/**
 * Venam Admin Scripts
 */
(function($) {
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip({
            placement: 'top',
            html: true
        });
    });
})( jQuery );
